package edu.lab.problem2;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class MainApp extends Application {
 @Override public void start(Stage stage) throws Exception {
  FXMLLoader loader = new FXMLLoader(MainApp.class.getResource("/sample.fxml"));
  stage.setTitle("Label and ImageView - JavaFX");
  stage.setScene(new Scene(loader.load(), 500, 400)); stage.show();
 }
 public static void main(String[] args) { launch(args); }
}
