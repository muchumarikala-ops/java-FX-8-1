# Problem 2: JavaFX Label and ImageView

## Aim
Display text in a Label and an image in an ImageView. The GUI layout is in FXML, which can be opened in JavaFX Scene Builder.

## Files
- `src/main/java/edu/lab/problem2/MainApp.java` — loads the FXML window.
- `src/main/resources/sample.fxml` — GUI layout.
- `src/main/resources/sample.png` — image displayed in ImageView (add/replace with your own image).
- `pom.xml` — project configuration.

## Run
Install JDK 17+ and Maven. From this folder run `mvn javafx:run`.

## Scene Builder
Open `src/main/resources/sample.fxml` in JavaFX Scene Builder to view or edit the layout. The GUI components are defined in FXML rather than manually laid out in Java code.
